# Sistema de Gestión de Matrículas Académicas - FET

Proyecto del parcial final: análisis y diseño de un sistema de matrículas para la Fundación Escuela Tecnológica de Neiva (FET).

## Integrantes
- [Nombre completo 1]
- [Nombre completo 2]
- [Nombre completo 3]

**Curso:** [Nombre del curso] · **Docente:** [Nombre del docente] · **Fecha:** 11 de noviembre de 2026

## Descripción
La FET maneja parte de sus matrículas de forma manual o en hojas de cálculo, lo que genera errores, demoras y poco control de los cupos. Este proyecto propone un sistema que permite:

- Registrar estudiantes y consultar sus datos.
- Consultar asignaturas, horarios y cupos disponibles.
- Verificar requisitos y conflictos de horario.
- Matricular o cancelar asignaturas.
- Generar comprobantes y reportes académicos.

## Enfoques aplicados
- **Estructurado:** cinco procesos principales y diagrama de flujo de la matrícula.
- **Orientado a objetos:** clases `Estudiante`, `Asignatura` y `Matricula` con su diagrama UML.
- **Ágil:** plan de cuatro Sprints de dos semanas.

## Estructura del repositorio
```
.
├── README.md
├── docs/   # Documento PDF con el análisis, diagramas y referencias
└── src/    # Código fuente del proyecto
```

## Documentación
El informe completo está en [`docs/Enfoques_Desarrollo_Software_Matriculas_FET.pdf`](docs/Enfoques_Desarrollo_Software_Matriculas_FET.pdf).

## Ejecución
[Escribir aquí las instrucciones para ejecutar el proyecto: tecnologías usadas, dependencias y comandos.]
